/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto.pkg2;

/**
 *
 * @author valle
 */
//Clase persona
public class Persona {
    private String nombre;
    private String sobreNombre;
    private Lista padres;
    private String conocidoComo;
    private String titulo;
    private String conyuge;
    private String colorOjos;
    private String colorCabello;
    private Lista hijos;
    private String notas;
    private String destino;
    private Persona padre;
    //Constructor
    public Persona(){
        this.nombre="no encontrado";
        this.sobreNombre="no encontrado";
        this.padres=new Lista();
        this.conocidoComo="no encontrado";
        this.titulo="no encontrado";
        this.conyuge="no encontrado";
        this.colorOjos="no encontrado";
        this.colorCabello="no encontrado";
        this.hijos=new Lista();
        this.notas="no encontrado";
        this.destino="no encontrado";
        this.padre=null;
    }
    //Getters y Setters
    public String getNombre(){
        return nombre;
    }
    public void setNombre(String nombre){
        this.nombre=nombre;
    }
    public String getSobreNombre(){
        return sobreNombre;
    }
    public void setSobreNombre(String sobreNombre){
        this.sobreNombre=sobreNombre;
    }
    public Lista getPadres(){
        return padres;
    }
    public void setPadres(String padres){
        this.padres.insertar(padres);
    }
    public String getConocidoComo(){
        return conocidoComo;
    }
    public void setConocidoComo(String conocidoComo){
        this.conocidoComo=conocidoComo;
    }
    public String getTitulo(){
        return titulo;
    }
    public void setTitulo(String titulo){
        this.titulo=titulo;
    }
    public String getConyuge(){
        return conyuge;
    }
    public void setConyuge(String conyuge){
        this.conyuge=conyuge;
    }
    public String getColorOjos(){
        return colorOjos;
    }
    public void setColorOjos(String colorOjos){
        this.colorOjos=colorOjos;
    }
    public String getColorCabello(){
        return colorCabello;
    }
    public void setColorCabello(String colorCabello){
        this.colorCabello=colorCabello;
    }
    public Lista getHijos(){
        return hijos;
    }
    public void setHijos(String hijos){
        this.hijos.insertar(hijos);
    }
    public String getNotas(){
        return notas;
    }
    public void setNotas(String notas){
        this.notas=notas;
    }
    public String getDestino(){
        return destino;
    }
    public void setDestino(String destino){
        this.destino=destino;
    }
    public Persona getPadre(){
        return padre;
    }
    public void setPadre(Persona info){
        this.padre=info;}
    
    
}
