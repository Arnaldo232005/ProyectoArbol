/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto.pkg2;

/**
 *
 * @author valle
 */
//clase hashTable
public class HashTable {
    private HashNodo[] balde;
    private String nombre;
    private int numBalde;
    private int size;
    //Constructor
    public HashTable(){
        this.numBalde=10;
        this.balde=new HashNodo[numBalde];
        this.size=0;
    }
    //Función Hash
    private int getBaldeIndex(String llave){
        int hashCode=llave.hashCode();
        return Math.abs(hashCode%numBalde);
    }
    //Función insertar
    public void insertar(String llave, Persona valor){
        int baldeIndex=getBaldeIndex(llave);
        HashNodo cabeza=balde[baldeIndex];
        //asegurar que la llave no exista
        while(cabeza!=null){
            if (cabeza.llave.equals(llave)){
                cabeza.valor=valor;
                return;
            }
            cabeza=cabeza.sig;
        }
        //Insertar nuevo nod
        size++;
        cabeza=balde[baldeIndex];
        HashNodo nuevoNodo=new HashNodo(llave,valor);
        nuevoNodo.sig=cabeza;
        balde[baldeIndex]=nuevoNodo;
        
    }
    //Función obtener
    public Persona obtener(String llave){
        int baldeIndex=getBaldeIndex(llave);
        HashNodo cabeza=balde[baldeIndex];
        while (cabeza!=null){
            if (cabeza.llave.equals(llave)){
                return cabeza.valor;
            }
            cabeza=cabeza.sig;
        }
        return null;
    }
    //Función eliminar
    public Persona eliminar(String llave){
        int baldeIndex=getBaldeIndex(llave);
        HashNodo cabeza=balde[baldeIndex];
        HashNodo previo=null;
        while(cabeza!=null){
            if (cabeza.llave.equals(llave)){
                break;
            }
            previo=cabeza;
            cabeza=cabeza.sig;
        }
        if (cabeza==null){
            return null;
        }
        size--;
        if (previo!=null){
            previo.sig=cabeza.sig;
        }
        else{
            balde[baldeIndex]=cabeza.sig;
        }
        return cabeza.valor;
    }
        //Getters y Setters
    public String getNombre(){
        return nombre;
    }
    public void setNombre(String nombre){
        this.nombre=nombre;
    }
    
}
