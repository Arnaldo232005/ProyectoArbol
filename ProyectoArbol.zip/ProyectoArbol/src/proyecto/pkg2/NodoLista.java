/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto.pkg2;

/**
 *
 * @author valle
 */
public class NodoLista {//clase Nodo2
    NodoLista sig;//crear nod siguiente
    String info;//crear informacion del nodo string

public NodoLista(String i,NodoLista s){//inicializar constructor
    info=i;//la informacion del nodo es igual a i
    sig=s;//el nodo siguiente del nodo es igual a s
}
public String getInfo(){//mostar la informacion del nodo
    return info;
}
public void setInfo(String info){//añadir la informacion del nodo
    this.info=info;
}
public NodoLista getSig(){//mostrar el nodo siguiente del nodo
    return sig;
}
public void setSig(NodoLista sig){//añadir el nodo siguiente del nodo
    this.sig=sig;
}  
}
