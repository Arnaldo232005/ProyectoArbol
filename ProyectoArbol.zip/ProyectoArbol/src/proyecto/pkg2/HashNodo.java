/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto.pkg2;

/**
 *
 * @author valle
 */
//Clas del nodo del hashTable
public class HashNodo {
    String llave;
    Persona valor;
    HashNodo sig;
    //Constructor
    public HashNodo(String k, Persona V){
        this.llave=k;
        this.valor=V;
    }
    
    
}
