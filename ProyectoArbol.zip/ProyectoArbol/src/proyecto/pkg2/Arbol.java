/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto.pkg2;

/**
 *
 * @author valle
 */
//clases arbol
public class Arbol {
    private NodoArbol raiz;

    public Arbol() {
        this.raiz = null;
    }

    public NodoArbol getRaiz() {
        return raiz;
    }

    public void setRaiz(Persona persona) {
        this.raiz = new NodoArbol();
        this.raiz.setInfo(persona);
    }
    public boolean isEmpty(){
        return this.raiz==null;
    }

    // Método para buscar un nodo con cierta información
    public NodoArbol buscarNodo(NodoArbol nodo, Persona info) {
        if (nodo == null) return null;
        if (nodo.getInfo().equals(info)) return nodo;

        NodoArbol encontrado = buscarNodo(nodo.hijoIZ, info);
        if (encontrado == null) {
            encontrado = buscarNodo(nodo.herDer, info);
        }

        return encontrado;
    }

    // Método para añadir un hijo a un nodo específico encontrado por información del padre
    public boolean agregarHijo(Persona padreInfo, Persona hijoInfo) {
        hijoInfo.setPadre(padreInfo);
        NodoArbol padre = buscarNodo(raiz, padreInfo);
        if (padre == null) {
            System.out.println("El nodo padre no fue encontrado.");
            return false;
        }

        NodoArbol nuevoHijo = new NodoArbol();
        nuevoHijo.setInfo(hijoInfo);

        if (padre.hijoIZ == null) {
            padre.hijoIZ = nuevoHijo;
        } else {
            NodoArbol actual = padre.hijoIZ;
            while (actual.herDer != null) {
                actual = actual.herDer;
            }
            actual.herDer = nuevoHijo;
        }

        return true;
    }
    //Funcion buscar padre de un nodo
    public NodoArbol buscarPadre(NodoArbol nodo, Persona info) { 
        if (nodo == null || nodo.hijoIZ == null) return null; 
        NodoArbol actual = nodo.hijoIZ; 
        while (actual != null) { 
            if (actual.getInfo()==info) { 
                return nodo; } 
            NodoArbol encontrado = buscarPadre(actual, info); 
            if (encontrado != null) {
                return encontrado; }
            actual = actual.herDer; }
        return null; }

    // Método para imprimir el árbol (preorden)
    public Lista imprimirPreorden(NodoArbol nodo,Persona persona,Lista lista) {
        if (nodo!=null){
        if (nodo.info==persona){
            return lista;
        }
        lista.insertar(nodo.info.getNombre());
        imprimirPreorden(nodo.hijoIZ,persona,lista);
        imprimirPreorden(nodo.herDer,persona,lista);
        }
        return null;
    }
    // Método para obtener los antepasados de una persona 
    public Lista obtenerAntepasados(Persona info) { 
        Lista antepasados = new Lista(); 
        encontrarAntepasados(raiz, info, antepasados); 
        return antepasados; } 
    // Método auxiliar para encontrar y acumular antepasados 
    private boolean encontrarAntepasados(NodoArbol nodo, Persona info, Lista antepasados) { 
        if (nodo == null) return false; 
        if (nodo.getInfo()==info) { return true; } 
        if (encontrarAntepasados(nodo.hijoIZ, info, antepasados) || encontrarAntepasados(nodo.herDer, info, antepasados)) { 
            antepasados.insertar(nodo.getInfo().getNombre()); return true; }
        return false; }
    
}


    

