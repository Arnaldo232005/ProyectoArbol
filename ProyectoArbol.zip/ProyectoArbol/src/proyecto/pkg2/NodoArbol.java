/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto.pkg2;

/**
 *
 * @author valle
 */
//Clase nodo de Arbol
public class NodoArbol {//nod del árbol
    public Persona info;//información del nodo
    public NodoArbol hijoIZ;//hijo izquierdo del nodo
    public NodoArbol herDer;//hermano derecho del nodo
    //Getters y setters
    public Persona getInfo(){
        return info;
    }
    public void setInfo(Persona info){
        this.info=info;}
    
}
