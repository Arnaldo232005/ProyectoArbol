/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package proyecto.pkg2;
import org.graphstream.graph.*;
import org.graphstream.graph.implementations.*;


/**
 *
 * @author valle
 */
public class Menu extends javax.swing.JFrame {

    /**
     * Creates new form Menu
     */
    public Menu() {
        initComponents();
    }
    //Procedimiento añadir dato
    private String dato;
    public void setDato(String dato){
        this.dato=dato; 
    }
    private Persona persona;
    private String titulo;
    private HashTable hashTable=new HashTable();
    private Lista hashList=new Lista();
    private Lista hashList2=new Lista();
    private Arbol arbol=new Arbol();
    private Lista repetidos=new Lista();
    private int nm=2;
    private Lista personasApodos=new Lista();
    private Lista verificarApodos=new Lista();
    private Lista listaArbol=new Lista();
    private Lista listaId=new Lista();
    private Lista list=new Lista();
    private Lista rep=new Lista();
    private Lista listaTitulos=new Lista();
    private Lista listaTitulos2=new Lista();
    String m;
    String[] apellidon;
    String apellido;
    boolean iniciar=false;
    //Procedimiento añadir titulos
    public void setTitulos(String dato){
        if (listaTitulos.buscar(dato)==false){
            listaTitulos.insertar(dato);
    } 
    }
    //Procedimiento insertar en hashTable
    public void setInHashTable(Persona info){
        m=info.getNombre();
        apellidon=m.split(" ");
        apellido=apellidon[1];
        if (list.buscar(info.getNombre())==true){
            if (repetidos.buscar(info.getNombre())==false){
                repetidos.insertar(info.getNombre());
            }
        }
        list.insertar(info.getNombre());
        
        if (arbol.isEmpty()){
            arbol.setRaiz(info);
            hashList2.insertar(info.getNombre());
        }
        String nombre;
        if (info.getConocidoComo().equals("no encontrado")){
           nombre=info.getNombre()+" "+info.getSobreNombre()+" of his name";
           hashList.insertar(nombre);
           hashTable.insertar(nombre, info);
        }
        else {
            hashList.insertar(info.getConocidoComo());
            hashTable.insertar(info.getConocidoComo(), info);
            personasApodos.insertar(info.getConocidoComo());
        }
        
    }
    //Procedimiento generar arbol
    public void generarArbol(){
        int n=1;
        int nh=0;
        String personan;
        Persona per=new Persona();
        while(n<hashList.listaTamaño()){
            personan=hashList.obtenerValor(n);
            if (personan!=null){
                Persona personaTable=hashTable.obtener(personan);
                String padre=personaTable.getPadres().obtenerValor(0);
                String[] condicion=padre.split(" ");
                if(condicion.length==6){
                    Persona padreTable=hashTable.obtener(padre);
                    if (padreTable==null){
                        padre=personasApodos.obtenerValor(nh);
                        if(padre==null){
                           padre=personasApodos.obtenerValor(nh-1); 
                        }
                        padreTable=hashTable.obtener(padre);
                        verificarApodos.insertar(padre);
                        nh+=1;   
                    }
                    per=padreTable;
                    arbol.agregarHijo(padreTable, personaTable);
                }else if (condicion[1].equals(apellido)){
                    String nPadre=padre+" "+per.getSobreNombre()+" of his name";
                    Persona padreTable=hashTable.obtener(nPadre);
                    per=padreTable;
                    arbol.agregarHijo(padreTable, personaTable);
                }else{
                Persona padreTable=hashTable.obtener(padre);
                per=padreTable;
                if (verificarApodos.buscar(padre)==false){
                    nh+=1;
                    verificarApodos.insertar(padre);
                }
                arbol.agregarHijo(padreTable, personaTable);}
            }
            n+=1;
            
        }
            }
        //Procedimiento generar grafo de la familia    
        public void generarGrafo(NodoArbol nodo, Lista lista,Graph grafo) {
        if (nodo == null) return;
        String nodoUno=nodo.info.getNombre()+nodo.info.getSobreNombre();
        if (lista.buscar(nodoUno)==false){
            lista.insertar(nodoUno);
            graph.addNode(nodoUno);//añadir el nombre de nuevaEstacion a graph
            graph.getNode(nodoUno).setAttribute("ui.label", nodoUno);//añadir nombre a nodo
            graph.getNode(nodoUno).setAttribute("ui.style", "fill-color: " + "green" + "; size: 15px; shape: circle;");}
        NodoArbol nodoHijo=nodo.hijoIZ;
        if(nodoHijo!=null){
        String nodoDos=nodoHijo.info.getNombre()+nodoHijo.info.getSobreNombre();
        if (lista.buscar(nodoDos)==false){
            lista.insertar(nodoDos);
            graph.addNode(nodoDos);//añadir el nombre de nuevaEstacion a graph
            graph.getNode(nodoDos).setAttribute("ui.label", nodoDos);//añadir nombre a nodo
            graph.getNode(nodoDos).setAttribute("ui.style", "fill-color: " + "green" + "; size: 15px; shape: circle;");}
        String union=nodoUno+nodoDos;
        if (listaId.buscar(union)==false){
            graph.addEdge(union, nodoUno, nodoDos);
            listaId.insertar(union);
        }
        while (nodoHijo.herDer!=null){
            String nodoTres=nodoHijo.herDer.info.getNombre()+nodoHijo.herDer.info.getSobreNombre();
            if (lista.buscar(nodoTres)==false){
            lista.insertar(nodoTres);
            graph.addNode(nodoTres);//añadir el nombre de nuevaEstacion a graph
            graph.getNode(nodoTres).setAttribute("ui.label", nodoTres);//añadir nombre a nodo
            graph.getNode(nodoTres).setAttribute("ui.style", "fill-color: " + "green" + "; size: 15px; shape: circle;");}
        union=nodoUno+nodoTres;
        if (listaId.buscar(union)==false){
            graph.addEdge(union, nodoUno, nodoTres);
            listaId.insertar(union);
        }
        nodoHijo=nodoHijo.herDer;
            
            
        }}
        

        
        generarGrafo(nodo.hijoIZ,lista,grafo);
        generarGrafo(nodo.herDer,lista,grafo);
    }
        
    //Crear grafo
    Graph graph = new SingleGraph("Tutorial 1");//crear grafo de GraphStream

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Buscar3 = new javax.swing.JButton();
        jTextField1 = new javax.swing.JTextField();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        Pantalla = new javax.swing.JTextArea();
        verArbol = new javax.swing.JButton();
        buscarTitulo = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        buscarPersona = new javax.swing.JTextField();
        BuscarNombre = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        BuscarTitulo = new javax.swing.JButton();
        Buscar4 = new javax.swing.JButton();
        Buscar5 = new javax.swing.JButton();
        tvt = new javax.swing.JTextField();
        tvt2 = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();

        Buscar3.setBackground(new java.awt.Color(204, 153, 0));
        Buscar3.setFont(new java.awt.Font("Century Gothic", 0, 15)); // NOI18N
        Buscar3.setText("ENTER");
        Buscar3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Buscar3ActionPerformed(evt);
            }
        });

        jTextField1.setText("jTextField1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Pantalla.setBackground(new java.awt.Color(51, 51, 51));
        Pantalla.setColumns(20);
        Pantalla.setFont(new java.awt.Font("Century Gothic", 0, 14)); // NOI18N
        Pantalla.setForeground(new java.awt.Color(204, 153, 0));
        Pantalla.setRows(5);
        jScrollPane1.setViewportView(Pantalla);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 110, 200, 250));

        verArbol.setBackground(new java.awt.Color(204, 153, 0));
        verArbol.setFont(new java.awt.Font("Century Gothic", 0, 15)); // NOI18N
        verArbol.setText("VER ÁRBOL");
        verArbol.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                verArbolActionPerformed(evt);
            }
        });
        jPanel1.add(verArbol, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 430, 140, 30));

        buscarTitulo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buscarTituloActionPerformed(evt);
            }
        });
        jPanel1.add(buscarTitulo, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 350, 150, 20));

        jLabel3.setFont(new java.awt.Font("Century Gothic", 0, 15)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(204, 153, 0));
        jLabel3.setText("BUSCAR PERSONAS (NOMBRE)");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 180, 230, 40));

        buscarPersona.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buscarPersonaActionPerformed(evt);
            }
        });
        jPanel1.add(buscarPersona, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 230, 150, 20));

        BuscarNombre.setBackground(new java.awt.Color(204, 153, 0));
        BuscarNombre.setFont(new java.awt.Font("Century Gothic", 0, 15)); // NOI18N
        BuscarNombre.setText("BUSCAR");
        BuscarNombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BuscarNombreActionPerformed(evt);
            }
        });
        jPanel1.add(BuscarNombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 270, 180, 30));

        jLabel4.setFont(new java.awt.Font("Century Gothic", 0, 15)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(204, 153, 0));
        jLabel4.setText("BUSCAR PERSONAS (TÍTULO)");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 300, 230, 40));

        BuscarTitulo.setBackground(new java.awt.Color(204, 153, 0));
        BuscarTitulo.setFont(new java.awt.Font("Century Gothic", 0, 15)); // NOI18N
        BuscarTitulo.setText("BUSCAR");
        BuscarTitulo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BuscarTituloActionPerformed(evt);
            }
        });
        jPanel1.add(BuscarTitulo, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 390, 180, 30));

        Buscar4.setBackground(new java.awt.Color(204, 153, 0));
        Buscar4.setFont(new java.awt.Font("Century Gothic", 0, 15)); // NOI18N
        Buscar4.setText("INICIAR");
        Buscar4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Buscar4ActionPerformed(evt);
            }
        });
        jPanel1.add(Buscar4, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 110, 180, 70));

        Buscar5.setBackground(new java.awt.Color(204, 153, 0));
        Buscar5.setFont(new java.awt.Font("Century Gothic", 0, 15)); // NOI18N
        Buscar5.setText("VER REGISTRO");
        Buscar5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Buscar5ActionPerformed(evt);
            }
        });
        jPanel1.add(Buscar5, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 380, 140, 30));

        tvt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tvtActionPerformed(evt);
            }
        });
        jPanel1.add(tvt, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 230, 30, -1));

        tvt2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tvt2ActionPerformed(evt);
            }
        });
        jPanel1.add(tvt2, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 350, 30, -1));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto/pkg2/Brown Beige Tree Business Fundation Logo (1).png"))); // NOI18N
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 500, 480));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 501, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    //Procedimiento visualizar arbol de familia
    private void verArbolActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_verArbolActionPerformed
        if (iniciar==true){
            this.generarGrafo(arbol.getRaiz(), listaArbol, graph);
            System.setProperty("org.graphstream.ui", "swing");//mostrar grafo
            graph.display();}
        else{
            Pantalla.setText("Recuerde darle iniciar");
        }
            
            

        

    }//GEN-LAST:event_verArbolActionPerformed
    
    private void buscarTituloActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buscarTituloActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_buscarTituloActionPerformed

    private void buscarPersonaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buscarPersonaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_buscarPersonaActionPerformed
    //Procedimiento buscar nombre de persona
    private void BuscarNombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BuscarNombreActionPerformed
        if (iniciar==true){
        String aux=buscarPersona.getText();
        int numero2=0;
        int numero=0;
        String pers3=new String();
        String pers=new String();
        while (numero<=hashList.listaTamaño()){
            pers=hashList.obtenerValor(numero);
            if (pers!=null){
            String[] pers2=pers.split(" ");
            pers=pers2[0]+" "+pers2[1];
            if (pers.equals(aux)){
               aux=hashList.obtenerValor(numero);
               pers=pers;
               break;
            }}
            numero+=1;
            
        }
                
        if (repetidos.buscar(pers)){
            String apm=tvt.getText();
            pers=pers+" "+apm+" of his name";
            persona=hashTable.obtener(pers);
            if (persona==null){
                Pantalla.setText("Hay más miembros del árbol\ncon este nombre seleccione\nel numero en ingles\nen la casilla por ejemplo First");
            }else{
            Lista antepasados=arbol.obtenerAntepasados(persona);
            Pantalla.setText(antepasados.recorrer());}
            
            }
        else if (hashList.buscar(aux)==true){
            persona=hashTable.obtener(aux);
            Lista antepasados=arbol.obtenerAntepasados(persona);
            Pantalla.setText(antepasados.recorrer());
            
        
        }
        else{
            

            Pantalla.setText("No se ha encontrado\nverifique que este\nbien escrito o\nprueba con su apodo");
        }
}
        else{
            Pantalla.setText("Recuerde darle iniciar");
        }
// TODO add your handling code here:
    }//GEN-LAST:event_BuscarNombreActionPerformed
    //Buscar titulo de personas
    private void BuscarTituloActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BuscarTituloActionPerformed

        if (iniciar==true){
        String aux=buscarTitulo.getText();
        int numero2=0;
        String titulo=null;
        while(numero2<=listaTitulos.listaTamaño()){
            titulo=listaTitulos.obtenerValor(numero2);
            if (titulo!=null){
            if (titulo.equals(aux)){
                titulo=titulo;
                break;
            }}
            numero2+=1;
        }
        if(titulo!=null){
        int numero=0;
        String pers=new String();
        while (numero<=hashList.listaTamaño()){
            pers=hashList.obtenerValor(numero);
            if (pers!=null){
            persona=hashTable.obtener(pers);
            if (persona.getTitulo().equals(titulo)){
            listaTitulos2.insertar(pers);}
}
            numero+=1;
            
        }}else{
            Pantalla.setText("Nose encontró ese titulo");
        }}else{
            Pantalla.setText("Recuerde darle iniciar");
        }
        String numT=tvt2.getText();
        if (numT.isEmpty()){
            Pantalla.setText("Escriba una opción\ndisponible o un número en\nel recuadro para buscar\npor ejemplo 1");
        }else{
        int numTitulo=Integer.parseInt(numT);
        if(numTitulo<=listaTitulos2.listaTamaño()){
        numT=listaTitulos2.obtenerValor(numTitulo);
        persona=hashTable.obtener(numT);
        Lista antepasados=arbol.obtenerAntepasados(persona);
        Pantalla.setText(antepasados.recorrer());}
        else{
            Pantalla.setText("Ese numero es mayor a\nla cantidad de personas que\nhan tenido este titulo");
                }}
        
    }//GEN-LAST:event_BuscarTituloActionPerformed

    private void Buscar3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Buscar3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Buscar3ActionPerformed
    //Procedimiento iniciar
    private void Buscar4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Buscar4ActionPerformed
        if (iniciar==false){
        this.generarArbol();}
        Pantalla.setText("Bienvenid@ "+dato+" Listo para iniciar");
        iniciar=true;
    }//GEN-LAST:event_Buscar4ActionPerformed
    //Procedimiento ver registro
    private void Buscar5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Buscar5ActionPerformed
        if (persona!=null && iniciar==true){
           String informacion="Nombre:"+persona.getNombre()+"\n"+"Conocido como:"+persona.getConocidoComo()+"\n"+"Sobre su Nombre:"+persona.getSobreNombre()+"\n"+"Padres:"+persona.getPadres().recorrer()+"\n"+"Título:"+persona.getTitulo()+"\n"+"Ojos:"+persona.getColorOjos()+"\n"+"Cabello:"+persona.getColorCabello()+"\n"+"Hijos:"+persona.getHijos().recorrer()+"\n"+"Destino:"+persona.getDestino()+"\n"+"Notas:"+persona.getNotas();
           Pantalla.setText(informacion);
        }
        else{
            Pantalla.setText("Recuerdar darle iniciar y\nbuscar una opcion\ndisponible");
        }

        

        
    }//GEN-LAST:event_Buscar5ActionPerformed

    private void tvtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tvtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tvtActionPerformed

    private void tvt2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tvt2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tvt2ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Menu().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Buscar3;
    private javax.swing.JButton Buscar4;
    private javax.swing.JButton Buscar5;
    private javax.swing.JButton BuscarNombre;
    private javax.swing.JButton BuscarTitulo;
    private javax.swing.JTextArea Pantalla;
    private javax.swing.JTextField buscarPersona;
    private javax.swing.JTextField buscarTitulo;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField tvt;
    private javax.swing.JTextField tvt2;
    private javax.swing.JButton verArbol;
    // End of variables declaration//GEN-END:variables
}
