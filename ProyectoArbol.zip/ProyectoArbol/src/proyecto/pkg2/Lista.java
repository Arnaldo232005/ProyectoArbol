/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto.pkg2;

/**
 *
 * @author valle
 */

public class Lista {//clase Lista
    NodoLista pLast;//crear nodo último
    NodoLista pFirst;//crear nodo primero
    public Lista(){//inicializar constructor
        pFirst=null;
        pLast=null;
    }
    public void insertar(String info){//método insertar en la lista
        NodoLista pAux = new NodoLista(info,null);//crear nodo auxiliar
        if (pFirst==null){//si nodo primero es igual a null
            pLast=pAux;//nodo primero y último son iguales al nodo auxiliar
            pFirst=pLast;
        }
        else {
            pLast.setSig(pAux);//si no nodo auxiliar se añade a la lista y se convierte en el nodo último
            pLast=pAux;   
        }
    }
    Boolean buscar(String x){//funcion buscar con retorno booleano
        NodoLista pAux=pFirst;//nodo auxiliar es igual a nodo primero
        Boolean result=false;
        while(pAux!=null){//mientras nodo auxiliar sea distinto a null
            if ((pAux.info).equals(x)){//si el nombre de la estacion del nodo auxiliar es igual al string x
                result=true;//retornar verdadero
            }
            pAux=pAux.sig;//nodo auxiliar es igual a siguiente
        }
        return result;//retornar falso
    
}
        String recorrer(){//funcion buscar con retorno booleano
        NodoLista pAux=pFirst;//nodo auxiliar es igual a nodo primero
        String result=new String();
        while(pAux!=null){//mientras nodo auxiliar sea distinto a null
            result=result+"\n"+pAux.info;
            pAux=pAux.sig;//nodo auxiliar es igual a siguiente
        }
        return result;//retornar falso
}
        int obtenerIndice(String x){
        NodoLista pAux=pFirst;//nodo auxiliar es igual a nodo primero
        int result=0;
        while(pAux!=null){//mientras nodo auxiliar sea distinto a null
            if (pAux.info==x){
               return result; 
            }
            pAux=pAux.sig;//nodo auxiliar es igual a siguiente
            result+=1;
        }
        return result;//retornar falso
            
        }
        String obtenerValor (int x){
        NodoLista pAux=pFirst;//nodo auxiliar es igual a nodo primero
        int result=0;
        while(pAux!=null){//mientras nodo auxiliar sea distinto a null
            if (result==x){
               return pAux.info; 
            }
            pAux=pAux.sig;//nodo auxiliar es igual a siguiente
            result+=1;
        }
        return null;//retornar falso
            
        }
        int listaTamaño (){
        NodoLista pAux=pFirst;//nodo auxiliar es igual a nodo primero
        int result=0;
        while(pAux!=null){//mientras nodo auxiliar sea distinto a null
            pAux=pAux.sig;//nodo auxiliar es igual a siguiente
            result+=1;
        }
        return result;//retornar falso
            
        }
}
